import { API_BASE_URL, USE_SAMPLE_DATA } from './api';
import { findDemoResponse } from '../data/researchDemo';

// =====================================================================
// Data access for the AI Global Research Assistant.
//
// TODAY: no AI is connected. In sample mode this returns pre-written
// DEMONSTRATION answers (data/researchDemo.js), clearly labelled.
//
// LATER: set VITE_API_URL (see api.js and services/README.md). This file
// then POSTs the question to the Python backend, which must hold the AI
// provider's secret key. A key must NEVER be put in frontend code.
//
// Contract (planned, not built): POST /api/research/ask
// See services/README.md for the exact request and response shapes.
// =====================================================================

export const researchMode = USE_SAMPLE_DATA ? 'demo' : 'live';

const PROVENANCES = ['ai', 'verified', 'external', 'demo'];
const pickProvenance = (value, fallback) => (PROVENANCES.includes(value) ? value : fallback);
const asArray = (value) => (Array.isArray(value) ? value : []);
const asText = (value) => (typeof value === 'string' ? value : '');

// Only web links are allowed (blocks things like "javascript:" from a faulty backend)
const safeUrl = (value) => (typeof value === 'string' && /^https?:\/\//i.test(value) ? value : null);

// Makes sure whatever comes back has every field the interface expects,
// and applies the documented defaults for a missing `provenance`.
function normalizeResponse(raw, mode) {
  const textDefault = mode === 'demo' ? 'demo' : 'ai';
  const body = raw && typeof raw === 'object' ? raw : {};

  const summary = body.summary && typeof body.summary === 'object' ? body.summary : { text: body.summary };
  const findings = body.keyFindings && typeof body.keyFindings === 'object' && !Array.isArray(body.keyFindings)
    ? body.keyFindings
    : { items: body.keyFindings };
  const analysis = body.analysis && typeof body.analysis === 'object' ? body.analysis : null;

  return {
    mode,
    matched: body.matched,
    summary: {
      text: asText(summary.text) || 'No summary was returned.',
      provenance: pickProvenance(summary.provenance, textDefault),
    },
    keyFindings: {
      items: asArray(findings.items).map(asText).filter(Boolean),
      provenance: pickProvenance(findings.provenance, textDefault),
    },
    analysis: analysis
      ? {
          paragraphs: asArray(analysis.paragraphs).map(asText).filter(Boolean),
          provenance: pickProvenance(analysis.provenance, textDefault),
        }
      : null,
    sources: asArray(body.sources).map((source, i) => ({
      id: source.id ?? `s${i + 1}`,
      title: asText(source.title) || 'Untitled source',
      publisher: asText(source.publisher),
      url: safeUrl(source.url),
      provenance: pickProvenance(source.provenance, 'external'),
      note: asText(source.note),
    })),
    relatedTopics: asArray(body.relatedTopics)
      .map((topic) =>
        typeof topic === 'string'
          ? { label: topic, question: topic }
          : { label: asText(topic?.label) || asText(topic?.question), question: asText(topic?.question) || asText(topic?.label) }
      )
      .filter((topic) => topic.question),
    limitations: (Array.isArray(body.limitations) ? body.limitations : [body.limitations]).map(asText).filter(Boolean),
  };
}

function abortError() {
  return new DOMException('The request was stopped.', 'AbortError');
}

// A wait that can be cancelled with an AbortSignal (used by the Stop button)
function abortableDelay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError());
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError());
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

// question: the text the user typed
// history:  earlier turns as [{ role: 'user' | 'assistant', text }]
// signal:   an AbortSignal, so the Stop button can cancel the request
export async function askResearchQuestion({ question, history = [], signal }) {
  if (USE_SAMPLE_DATA) {
    // The wait only makes the loading state visible. No AI is running.
    await abortableDelay(1500 + Math.round(Math.random() * 500), signal);
    return normalizeResponse(findDemoResponse(question), 'demo');
  }

  let response;
  try {
    response = await fetch(`${API_BASE_URL}/api/research/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, history }),
      signal,
    });
  } catch (error) {
    if (error?.name === 'AbortError') throw error;
    throw new Error('Could not reach the research service. Check that the backend is running and that VITE_API_URL is correct.');
  }

  if (!response.ok) {
    throw new Error(`The research service answered with an error (${response.status}).`);
  }
  return normalizeResponse(await response.json(), 'live');
}
