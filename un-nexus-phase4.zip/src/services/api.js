// Connection settings for the future Python (FastAPI) backend.
//
// While VITE_API_URL is not set, the app runs on built-in SAMPLE data.
// To connect a backend later, create a file called `.env` in the frontend
// folder containing, for example:
//
//   VITE_API_URL=http://localhost:8000
//
// and restart `npm.cmd run dev`. The service files then call the backend
// instead of using sample data. NOTE: no backend exists yet, so the
// endpoints named in the service files are planned, not implemented.

export const API_BASE_URL = import.meta.env.VITE_API_URL || '';
export const USE_SAMPLE_DATA = API_BASE_URL === '';

// Waits `ms`. If an AbortSignal is given and fires, the wait ends early with an AbortError.
export const delay = (ms, signal) =>
  new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException('Aborted', 'AbortError'));
      return;
    }
    const id = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(id);
        reject(new DOMException('Aborted', 'AbortError'));
      },
      { once: true }
    );
  });

export async function apiGet(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, { signal: options.signal });
  if (!response.ok) {
    throw new Error(`The server answered with an error (${response.status}).`);
  }
  return response.json();
}

export async function apiPost(path, body, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: options.signal,
  });
  if (!response.ok) {
    throw new Error(`The server answered with an error (${response.status}).`);
  }
  return response.json();
}
