# Backend contract (planned)

These files talk to the future Python (FastAPI) backend. **The backend does not
exist yet.** While `VITE_API_URL` is not set, the app uses built-in sample data.

To connect a backend later, create a file named `.env` in the `frontend` folder:

```
VITE_API_URL=http://localhost:8000
```

Restart `npm.cmd run dev`. The AI provider's API key belongs on the backend only.
Never put it in the frontend.

## Situation Room

| Endpoint | Returns |
| --- | --- |
| `GET /api/countries` | `[{ id, name, region, position: [lat, lng], populationM, gdpB, indicators: { lifeExpectancy, renewableShare, internetUse } }]` |
| `GET /api/events` | `[{ id, countryId, category, severity, title, summary, occurredAt }]` |

`severity` is one of `low`, `moderate`, `high`, `critical`.

## Research Assistant

`POST /api/research/ask`

Request:

```json
{
  "question": "Which regions face the highest food insecurity?",
  "history": [{ "role": "user", "text": "..." }, { "role": "assistant", "text": "..." }]
}
```

Response:

```json
{
  "summary":     { "text": "...", "provenance": "ai" },
  "keyFindings": { "items": ["..."], "provenance": "ai" },
  "analysis":    { "paragraphs": ["..."], "provenance": "ai" },
  "sources": [
    { "id": "s1", "title": "...", "publisher": "...", "url": "https://...",
      "provenance": "verified", "note": "optional" }
  ],
  "relatedTopics": ["..."],
  "limitations": ["optional notes shown under the answer"]
}
```

`provenance` tells the reader where each part came from:

| Value | Meaning |
| --- | --- |
| `ai` | Written by an AI model |
| `verified` | Taken from a named official dataset or publication that the platform checked |
| `external` | A link to a third-party site, not checked by the platform |
| `demo` | Pre-written sample content (only used by the built-in demo) |

If `provenance` is missing, text sections default to `ai` and sources to `external`.
Only mark something `verified` if the backend really checked it.
