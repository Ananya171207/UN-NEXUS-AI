import { apiGet, delay, USE_SAMPLE_DATA } from './api';
import { countries } from '../data/countries';
import { sampleEvents } from '../data/situationEvents';

// Data access for the Global Situation Room.
// Pages call these functions and never import the sample files directly,
// so switching to the real backend only changes this file.

// Planned endpoint: GET /api/countries
export async function getCountries() {
  if (!USE_SAMPLE_DATA) return apiGet('/api/countries');
  await delay(350); // simulates a network request so loading states are visible
  return countries;
}

// Planned endpoint: GET /api/events
// Each event: { id, countryId, category, severity, title, summary, occurredAt }
export async function getEvents() {
  if (!USE_SAMPLE_DATA) return apiGet('/api/events');
  await delay(450);
  const now = Date.now();
  return sampleEvents.map((event) => ({
    ...event,
    occurredAt: new Date(now - event.hoursAgo * 3600 * 1000).toISOString(),
    isSample: true,
  }));
}

export const dataMode = USE_SAMPLE_DATA ? 'sample' : 'live';
