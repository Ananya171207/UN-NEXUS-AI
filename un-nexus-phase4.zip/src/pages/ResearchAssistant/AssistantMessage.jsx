import { Bot, ExternalLink, RotateCcw } from 'lucide-react';
import Accordion from '../../components/common/Accordion';
import CopyButton from '../../components/common/CopyButton';
import ProvenanceBadge from '../../components/common/ProvenanceBadge';
import { formatTime } from '../../utils/format';
import { responseToText } from './utils';

function SectionHead({ title, kind }) {
  return (
    <div className="ans-head">
      <h4>{title}</h4>
      <ProvenanceBadge kind={kind} />
    </div>
  );
}

export default function AssistantMessage({ message, isLast, loading, onAsk, onRegenerate }) {
  const r = message.response;

  return (
    <article className="msg msg-assistant" aria-label="Research assistant answer">
      <header className="msg-head">
        <span className="bot-avatar"><Bot size={15} /></span>
        <strong>Research assistant</strong>
        <ProvenanceBadge kind={r.mode === 'demo' ? 'demo' : 'ai'} short />
        <time dateTime={message.createdAt}>{formatTime(message.createdAt)}</time>
      </header>

      <section className="ans-section">
        <SectionHead title="Summary" kind={r.summary.provenance} />
        <p className="ans-summary">{r.summary.text}</p>
      </section>

      {r.keyFindings.items.length > 0 && (
        <section className="ans-section">
          <SectionHead title="Key findings" kind={r.keyFindings.provenance} />
          <ol className="findings">
            {r.keyFindings.items.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ol>
        </section>
      )}

      {r.analysis && (
        <Accordion
          title={
            <span className="acc-title">
              Detailed analysis <ProvenanceBadge kind={r.analysis.provenance} />
            </span>
          }
        >
          {r.analysis.paragraphs.map((paragraph) => (
            <p key={paragraph} className="ans-paragraph">{paragraph}</p>
          ))}
        </Accordion>
      )}

      {r.sources.length > 0 && (
        <section className="ans-section">
          <div className="ans-head"><h4>Source references</h4></div>
          <ul className="sources">
            {r.sources.map((source) => (
              <li key={source.id}>
                <div className="source-main">
                  {source.url ? (
                    <a href={source.url} target="_blank" rel="noopener noreferrer">
                      {source.title} <ExternalLink size={12} />
                    </a>
                  ) : (
                    <strong>{source.title}</strong>
                  )}
                  {source.publisher && <small>{source.publisher}</small>}
                  {source.note && <small className="source-note">{source.note}</small>}
                </div>
                <ProvenanceBadge kind={source.provenance} short />
              </li>
            ))}
          </ul>
        </section>
      )}

      {r.relatedTopics.length > 0 && (
        <section className="ans-section">
          <div className="ans-head"><h4>Related topics</h4></div>
          <div className="related">
            {r.relatedTopics.map((topic) => (
              <button key={topic.question} type="button" className="chip" disabled={loading} onClick={() => onAsk(topic.question)}>
                {topic.label}
              </button>
            ))}
          </div>
        </section>
      )}

      {r.limitations.length > 0 && (
        <ul className="limitations" aria-label="Limitations">
          {r.limitations.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      )}

      <footer className="msg-actions">
        <CopyButton text={responseToText(r)} label="Copy answer" />
        {isLast && (
          <button type="button" className="btn btn-ghost" onClick={onRegenerate} disabled={loading}>
            <RotateCcw size={13} /> Ask again
          </button>
        )}
      </footer>
    </article>
  );
}
