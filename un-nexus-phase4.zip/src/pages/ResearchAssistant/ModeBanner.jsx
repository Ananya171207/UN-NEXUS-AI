import { Info } from 'lucide-react';
import Accordion from '../../components/common/Accordion';
import { researchMode } from '../../services/researchService';

// Always visible: says plainly whether a real AI backend is connected.
export default function ModeBanner() {
  if (researchMode === 'live') {
    return (
      <div className="mode-banner live" role="status">
        <Info size={15} />
        <div>
          <strong>Connected to the research service</strong>
          <p>Answers come from the backend. Check the label on each section to see how it was produced.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mode-banner demo" role="status">
      <Info size={15} />
      <div>
        <strong>Demonstration mode · no AI model is connected</strong>
        <p>Answers are pre-written samples for five example topics. Nothing is generated or verified.</p>
        <Accordion title="What is needed to connect a real AI assistant">
          <ul className="plain-list">
            <li>A Python (FastAPI) backend that provides <code>POST /api/research/ask</code>.</li>
            <li>An AI provider account. Its API key must be stored on the backend, never in this frontend.</li>
            <li>Access to the sources the assistant should cite (UN publications, datasets).</li>
            <li>A <code>.env</code> file with <code>VITE_API_URL</code> pointing to the backend. See <code>src/services/README.md</code>.</li>
          </ul>
        </Accordion>
      </div>
    </div>
  );
}
