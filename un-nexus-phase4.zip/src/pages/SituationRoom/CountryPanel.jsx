import { useState } from 'react';
import { MapPin, X } from 'lucide-react';
import Panel from '../../components/common/Panel';
import Tabs from '../../components/common/Tabs';
import Accordion from '../../components/common/Accordion';
import CopyButton from '../../components/common/CopyButton';
import DataBadge from '../../components/common/DataBadge';
import EmptyState from '../../components/common/EmptyState';
import ProgressBar from '../../components/common/ProgressBar';
import { COUNTRY_DATA_NOTE } from '../../data/countries';
import { formatGdp, formatPopulation, formatRelative, formatUsd, gdpPerCapita } from '../../utils/format';
import { buildCountryBrief, deriveSdgIndicators } from './utils';

function Profile({ country }) {
  const { lifeExpectancy, renewableShare, internetUse } = country.indicators;
  const rows = [
    { label: 'Life expectancy', value: lifeExpectancy, unit: ' years', min: 40, max: 90 },
    { label: 'Renewable share of electricity', value: renewableShare, unit: '%', min: 0, max: 100 },
    { label: 'Internet use', value: internetUse, unit: '%', min: 0, max: 100 },
  ];

  return (
    <>
      <dl className="facts">
        <div><dt>Region</dt><dd>{country.region}</dd></div>
        <div><dt>Population</dt><dd>{formatPopulation(country.populationM)}</dd></div>
        <div><dt>GDP</dt><dd>{formatGdp(country.gdpB)}</dd></div>
        <div><dt>GDP per capita</dt><dd>{formatUsd(gdpPerCapita(country))}</dd></div>
      </dl>

      <h4 className="section-label">Development indicators</h4>
      <ul className="indicator-list">
        {rows.map((row) => (
          <li key={row.label}>
            <div className="indicator-top">
              <span>{row.label}</span>
              <strong>{row.value}{row.unit}</strong>
            </div>
            <ProgressBar value={row.value} min={row.min} max={row.max} label={row.label} />
          </li>
        ))}
      </ul>
    </>
  );
}

function SdgList({ country }) {
  return (
    <>
      <ul className="sdg-rows">
        {deriveSdgIndicators(country).map((item) => (
          <li key={item.goal}>
            <span className="sdg-chip">SDG {item.goal}</span>
            <div>
              <strong>{item.name}</strong>
              <small>{item.metric}: {item.value}</small>
            </div>
            <span className={`status-pill tone-${item.tone}`}>{item.label}</span>
          </li>
        ))}
      </ul>
      <p className="fine-print">
        Status labels use simple demonstration thresholds on sample values. They are not UN assessments.
        The full 17-goal view arrives with the SDG Tracker module.
      </p>
    </>
  );
}

function CountryEvents({ events, now, onOpenEvent }) {
  if (events.length === 0) {
    return <EmptyState title="No events for this country">The sample data holds no entries for it.</EmptyState>;
  }
  return (
    <ul className="mini-events">
      {events.map((event) => (
        <li key={event.id}>
          <button type="button" onClick={() => onOpenEvent(event.id)}>
            <span className={`severity severity-${event.severity}`}>{event.severity}</span>
            <strong>{event.title}</strong>
            <small>{event.category} · {formatRelative(event.occurredAt, now)}</small>
          </button>
        </li>
      ))}
    </ul>
  );
}

export default function CountryPanel({ country, events, suggestions, onPickCountry, onClear, onOpenEvent, now }) {
  const [tab, setTab] = useState('profile');

  if (!country) {
    return (
      <Panel title="Country information" subtitle="Select a pin on the map or search above" className="country-panel" index={3}>
        <EmptyState icon={MapPin} title="No country selected">
          Choose a country to see its profile, development indicators, SDG signals and recent events.
        </EmptyState>
        {suggestions.length > 0 && (
          <div className="quick-picks">
            <h4 className="section-label">Most active right now (sample)</h4>
            {suggestions.map((c) => (
              <button key={c.id} type="button" className="btn" onClick={() => onPickCountry(c.id)}>
                {c.name}
              </button>
            ))}
          </div>
        )}
      </Panel>
    );
  }

  const tabs = [
    { id: 'profile', label: 'Profile' },
    { id: 'sdg', label: 'SDG signals' },
    { id: 'events', label: 'Events', count: events.length },
  ];

  return (
    <Panel
      title={country.name}
      subtitle={country.region}
      className="country-panel"
      index={3}
      actions={
        <>
          <DataBadge type="sample" />
          <button type="button" className="icon-btn" onClick={onClear} aria-label="Clear selected country">
            <X size={16} />
          </button>
        </>
      }
    >
      <Tabs tabs={tabs} active={tab} onChange={setTab} label="Country sections" />

      <div className="tab-panel" key={tab}>
        {tab === 'profile' && <Profile country={country} />}
        {tab === 'sdg' && <SdgList country={country} />}
        {tab === 'events' && <CountryEvents events={events} now={now} onOpenEvent={onOpenEvent} />}
      </div>

      <div className="country-footer">
        <CopyButton text={buildCountryBrief(country, events)} label="Copy brief" />
      </div>

      <Accordion title="Source information">
        <ul className="source-list">
          <li><strong>Data type:</strong> Sample data. {COUNTRY_DATA_NOTE}</li>
          <li><strong>Events:</strong> Demonstration entries, not real news.</li>
          <li>
            <strong>Planned sources (not connected):</strong> official statistical databases for population,
            GDP and SDG indicators, supplied by the backend once it exists.
          </li>
        </ul>
      </Accordion>
    </Panel>
  );
}
